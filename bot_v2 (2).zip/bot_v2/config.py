# ═══════════════════════════════════════════════════════
#  config.py  –  Configuración central del bot
#  ⚠️  Cambia todos los valores antes de desplegar
# ═══════════════════════════════════════════════════════

BOT_TOKEN  = "TU_TOKEN_AQUI"
OWNER_ID   = 123456789
ADMIN_IDS  = [123456789]
CHANNEL_ID = -100123456789

DB_PATH = "bot_database.db"

PLANS = {
    "semanal":   {"days": 7,  "label": "Semanal"},
    "quincenal": {"days": 15, "label": "Quincenal"},
    "mensual":   {"days": 30, "label": "Mensual"},
}

DAILY_MIN_CONTRIBUTION = 1000
BAN_INACTIVITY_DAYS    = 1
RENEW_ALERT_DAYS       = 3

BANNED_WORDS = [
    # "palabra1",
    # "palabra2",
]

GROUP_RULES = (
    "📜 *Reglas del grupo*\n\n"
    "1️⃣ Respeto ante todo — no se toleran insultos.\n"
    "2️⃣ No compartas capturas del chat con externos.\n"
    "3️⃣ No hagas spam ni publicidad.\n"
    "4️⃣ Los aportadores deben cumplir el mínimo diario.\n"
    "5️⃣ El propietario y admins tienen la última palabra.\n\n"
    "_El incumplimiento resulta en ban inmediato._"
)

WELCOME_APPROVED = (
    "🎉 *¡Bienvenido/a, {name}!*\n\n"
    "Tu plan *{plan}* ha sido activado.\n"
    "Acceso válido hasta: `{end}`\n\n"
    "📌 Usa /reglas para conocer las normas.\n"
    "💬 Usa /chat para entrar al grupo.\n\n"
    "_Cualquier duda, usa /propietario._"
)

RENEW_ALERT_MSG = (
    "⏰ *Tu suscripción vence pronto*\n\n"
    "Plan: *{plan}*\n"
    "Vence: `{end}`\n\n"
    "Renueva antes de que expire para no perder el acceso.\n"
    "Toca el botón para renovar:"
)

OWNER_CONTACT_MESSAGE = (
    "📩 Tu mensaje fue enviado al propietario.\n"
    "Te responderá pronto."
)

WELCOME_MESSAGE = (
    "👋 *Bienvenido al bot privado.*\n\n"
    "Para acceder necesitas una suscripción activa.\n"
    "Usa /comprar para adquirir un plan."
)
