"""
handlers/payment.py  –  Flujo de compra
Nuevo flujo:
  1. Usuario elige plan
  2. Bot lo conecta directamente con el propietario
  3. Propietario le dice precio/método
  4. Usuario manda comprobante
  5. Propietario aprueba/rechaza desde el canal
"""

import logging
from datetime import datetime, timedelta
from telebot import types
from config import OWNER_ID, CHANNEL_ID, PLANS, WELCOME_APPROVED, GROUP_RULES


def _build_welcome(uid, plan_key, plan, bot_user=None):
    from database import Database
    # Construir mensaje de bienvenida personalizado
    end = (datetime.utcnow() + timedelta(days=plan["days"])).strftime("%Y-%m-%d")
    # Intentar obtener nombre del usuario desde Telegram
    name = str(uid)
    try:
        info = bot_user
        if info:
            name = info.full_name or info.username or str(uid)
    except Exception:
        pass
    return WELCOME_APPROVED.format(name=name, plan=plan["label"], end=end)

logger = logging.getLogger("PaymentHandler")

# Sesión de compra activa: {user_id: plan_key}
_buying_session = {}


def register_payment_handlers(bot, db):

    # ── /comprar ──────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["comprar", "planes"])
    def cmd_comprar(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            return
        db.upsert_user(uid, msg.from_user.username, msg.from_user.full_name)

        kb = types.InlineKeyboardMarkup(row_width=1)
        for key, plan in PLANS.items():
            kb.add(types.InlineKeyboardButton(
                f"📅 {plan['label']} ({plan['days']} días)",
                callback_data=f"buy_{key}"
            ))
        bot.send_message(
            uid,
            "💼 *Planes disponibles*\n\nElige el plan que quieres y te conecto con el propietario:",
            parse_mode="Markdown",
            reply_markup=kb
        )

    # ── Usuario elige plan → se conecta directo con el propietario ────────────
    @bot.callback_query_handler(func=lambda c: c.data.startswith("buy_"))
    def on_plan_selected(call):
        uid = call.from_user.id
        if db.is_banned(uid):
            bot.answer_callback_query(call.id, "Estás baneado.")
            return
        db.upsert_user(uid, call.from_user.username, call.from_user.full_name)

        plan_key = call.data[4:]
        if plan_key not in PLANS:
            bot.answer_callback_query(call.id, "Plan inválido.")
            return

        plan = PLANS[plan_key]
        bot.answer_callback_query(call.id)

        # Guardar sesión de compra
        _buying_session[uid] = plan_key

        # ── Notificar al propietario con botones de respuesta ─────────────────
        name = call.from_user.full_name or call.from_user.username or str(uid)
        kb_owner = types.InlineKeyboardMarkup()
        kb_owner.add(
            types.InlineKeyboardButton("💬 Responder", callback_data=f"ownerreply_{uid}"),
            types.InlineKeyboardButton("✅ Dar acceso directo", callback_data=f"directgrant_{uid}_{plan_key}"),
        )
        try:
            bot.send_message(
                OWNER_ID,
                f"🛒 *Nueva solicitud de compra*\n\n"
                f"👤 Usuario: `{uid}` @{call.from_user.username or '—'}\n"
                f"📛 Nombre: {name}\n"
                f"📅 Plan elegido: *{plan['label']}* ({plan['days']} días)\n\n"
                f"Respóndele para indicarle el precio y método de pago.",
                parse_mode="Markdown",
                reply_markup=kb_owner
            )
        except Exception as e:
            logger.error(f"Error notificando al owner: {e}")

        # ── Avisar al usuario ─────────────────────────────────────────────────
        bot.send_message(
            uid,
            f"✅ Elegiste el plan *{plan['label']}* ({plan['days']} días).\n\n"
            f"📩 Te conecté con el propietario. En breve te dirá el precio y cómo pagar.\n\n"
            f"Cuando te indiquen, envía aquí tu comprobante de pago (foto o captura).\n"
            f"Usa /cancelarcompra si quieres cancelar.",
            parse_mode="Markdown"
        )
        logger.info(f"Usuario {uid} inició compra del plan {plan_key}")

    # ── Usuario manda comprobante (foto/doc) estando en sesión de compra ──────
    @bot.message_handler(
        func=lambda m: m.chat.type == "private" and m.from_user.id in _buying_session,
        content_types=["photo", "document", "text"]
    )
    def receive_proof(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            _buying_session.pop(uid, None)
            return

        plan_key = _buying_session.get(uid)
        if not plan_key:
            return

        plan = PLANS.get(plan_key, {"label": plan_key, "days": 30})

        caption = (
            f"💳 *Comprobante de pago*\n"
            f"Usuario: `{uid}` @{msg.from_user.username or '—'}\n"
            f"Nombre: {msg.from_user.full_name or '—'}\n"
            f"Plan: *{plan['label']}* ({plan['days']} días)"
        )

        # ── Enviar al canal ───────────────────────────────────────────────────
        channel_msg = None
        kb_canal = types.InlineKeyboardMarkup()
        kb_canal.add(
            types.InlineKeyboardButton("✅ APROBAR", callback_data=f"chapprove_{uid}_{plan_key}"),
            types.InlineKeyboardButton("❌ RECHAZAR", callback_data=f"chreject_{uid}"),
        )
        try:
            if msg.content_type == "photo":
                channel_msg = bot.send_photo(
                    CHANNEL_ID, msg.photo[-1].file_id,
                    caption=caption, parse_mode="Markdown", reply_markup=kb_canal
                )
            elif msg.content_type == "document":
                channel_msg = bot.send_document(
                    CHANNEL_ID, msg.document.file_id,
                    caption=caption, parse_mode="Markdown", reply_markup=kb_canal
                )
            else:
                channel_msg = bot.send_message(
                    CHANNEL_ID,
                    caption + f"\n\n📝 Mensaje: {msg.text or '—'}",
                    parse_mode="Markdown", reply_markup=kb_canal
                )
        except Exception as e:
            logger.error(f"Error enviando al canal: {e}")

        # ── Guardar en DB ─────────────────────────────────────────────────────
        channel_msg_id = channel_msg.message_id if channel_msg else None
        payment_id = db.create_payment(uid, plan_key, channel_msg_id)

        # ── Reenviar al owner con botones ─────────────────────────────────────
        kb_owner = types.InlineKeyboardMarkup()
        kb_owner.add(
            types.InlineKeyboardButton("✅ Aprobar", callback_data=f"approve_{payment_id}"),
            types.InlineKeyboardButton("❌ Rechazar", callback_data=f"reject_{payment_id}"),
        )
        try:
            bot.send_message(OWNER_ID, f"📎 Comprobante recibido — Pago #{payment_id}:", parse_mode="Markdown")
            if msg.content_type == "photo":
                bot.send_photo(OWNER_ID, msg.photo[-1].file_id, caption=caption,
                               parse_mode="Markdown", reply_markup=kb_owner)
            elif msg.content_type == "document":
                bot.send_document(OWNER_ID, msg.document.file_id, caption=caption,
                                  parse_mode="Markdown", reply_markup=kb_owner)
            else:
                bot.send_message(OWNER_ID, caption + f"\n\n📝 {msg.text or '—'}",
                                 parse_mode="Markdown", reply_markup=kb_owner)
        except Exception as e:
            logger.error(f"Error notificando comprobante al owner: {e}")

        # Limpiar sesión de compra
        _buying_session.pop(uid, None)

        bot.send_message(
            uid,
            "✅ *Comprobante enviado.*\n"
            "El propietario lo revisará y recibirás una notificación cuando sea aprobado.",
            parse_mode="Markdown"
        )
        logger.info(f"Comprobante recibido de {uid}, pago #{payment_id}")

    # ── Aprobar/rechazar desde el CANAL ───────────────────────────────────────
    @bot.callback_query_handler(func=lambda c: c.data.startswith("chapprove_") or c.data.startswith("chreject_"))
    def channel_decision(call):
        if call.from_user.id != OWNER_ID:
            bot.answer_callback_query(call.id, "Solo el propietario puede hacer esto.")
            return

        if call.data.startswith("chapprove_"):
            _, uid_str, plan_key = call.data.split("_", 2)
            uid = int(uid_str)
            plan = PLANS.get(plan_key, {"label": plan_key, "days": 30})
            db.grant_access(uid, plan_key, plan["days"])
            db.log_action(call.from_user.id, "CHANNEL_APPROVED", uid, plan_key)
            try:
                user_info = db.get_user(uid)
                end = (datetime.utcnow() + timedelta(days=plan["days"])).strftime("%Y-%m-%d")
                name = (user_info["full_name"] or user_info["username"] or str(uid)) if user_info else str(uid)
                bot.send_message(
                    uid,
                    WELCOME_APPROVED.format(name=name, plan=plan["label"], end=end),
                    parse_mode="Markdown"
                )
                bot.send_message(uid, GROUP_RULES, parse_mode="Markdown")
            except Exception:
                pass
            bot.answer_callback_query(call.id, "✅ Acceso otorgado")
            bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)
            try:
                bot.send_message(call.message.chat.id, f"✅ Aprobado — Usuario `{uid}`", parse_mode="Markdown")
            except Exception:
                pass

        elif call.data.startswith("chreject_"):
            uid = int(call.data.split("_")[1])
            db.log_action(call.from_user.id, "CHANNEL_REJECTED", uid)
            try:
                bot.send_message(
                    uid,
                    "❌ Tu pago fue rechazado.\n"
                    "Contacta al propietario si tienes dudas."
                )
            except Exception:
                pass
            bot.answer_callback_query(call.id, "❌ Pago rechazado")
            bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)
            try:
                bot.send_message(call.message.chat.id, f"❌ Rechazado — Usuario `{uid}`", parse_mode="Markdown")
            except Exception:
                pass

    # ── Owner da acceso directo sin esperar comprobante ───────────────────────
    @bot.callback_query_handler(func=lambda c: c.data.startswith("directgrant_") and c.from_user.id == OWNER_ID)
    def direct_grant(call):
        _, uid_str, plan_key = call.data.split("_", 2)
        uid = int(uid_str)
        plan = PLANS.get(plan_key, {"label": plan_key, "days": 30})
        db.grant_access(uid, plan_key, plan["days"])
        db.log_action(OWNER_ID, "DIRECT_GRANT", uid, plan_key)
        bot.answer_callback_query(call.id, "✅ Acceso otorgado directamente")
        try:
            user_info = db.get_user(uid)
            end = (datetime.utcnow() + timedelta(days=plan["days"])).strftime("%Y-%m-%d")
            name = (user_info["full_name"] or user_info["username"] or str(uid)) if user_info else str(uid)
            bot.send_message(
                uid,
                WELCOME_APPROVED.format(name=name, plan=plan["label"], end=end),
                parse_mode="Markdown"
            )
            bot.send_message(uid, GROUP_RULES, parse_mode="Markdown")
        except Exception:
            pass
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)

    # ── /cancelarcompra ───────────────────────────────────────────────────────
    @bot.message_handler(commands=["cancelarcompra"])
    def cancel_buy(msg):
        uid = msg.from_user.id
        if uid in _buying_session:
            _buying_session.pop(uid)
            bot.send_message(uid, "❌ Compra cancelada.")
        else:
            bot.send_message(uid, "No tienes ninguna compra en proceso.")
