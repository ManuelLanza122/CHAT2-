"""
handlers/stats.py  –  Dashboard de estadísticas e informes diarios
"""

import logging
from telebot import types
from config import OWNER_ID, ADMIN_IDS, RENEW_ALERT_DAYS

logger = logging.getLogger("StatsHandler")


def register_stats_handlers(bot, db):

    # ── /dashboard ────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["dashboard", "stats"])
    def cmd_dashboard(msg):
        uid = msg.from_user.id
        if uid not in ADMIN_IDS and uid != OWNER_ID:
            return
        _send_dashboard(uid, bot, db)

    def _send_dashboard(uid, bot, db):
        s = db.get_dashboard_stats()
        by_plan = s["by_plan"]

        plan_lines = ""
        for plan, count in by_plan.items():
            plan_lines += f"   • {plan.capitalize()}: {count}\n"
        if not plan_lines:
            plan_lines = "   Sin suscriptores\n"

        expiring = db.get_expiring_this_week()
        exp_lines = ""
        for u in expiring[:5]:
            exp_lines += f"   • @{u['username'] or u['user_id']} — {u['access_end'][:10]}\n"
        if not exp_lines:
            exp_lines = "   Ninguno esta semana\n"

        texto = (
            f"📊 *Dashboard — {_today()}*\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"👥 *Usuarios*\n"
            f"   Total registrados: {s['total']}\n"
            f"   Suscriptores activos: {s['active']}\n"
            f"   Aportadores: {s['contributors']}\n"
            f"   Nuevos hoy: {s['new_today']}\n\n"
            f"💳 *Pagos*\n"
            f"   Aprobados hoy: {s['approved_today']}\n"
            f"   Pendientes: {s['pending_payments']}\n\n"
            f"📅 *Activos por plan*\n"
            f"{plan_lines}\n"
            f"⏰ *Vencen en {RENEW_ALERT_DAYS} días*\n"
            f"   En alerta: {s['expiring']}\n\n"
            f"📋 *Vencen esta semana*\n"
            f"{exp_lines}"
        )

        kb = types.InlineKeyboardMarkup()
        kb.add(types.InlineKeyboardButton("🔄 Actualizar", callback_data="refresh_dashboard"))
        bot.send_message(uid, texto, parse_mode="Markdown", reply_markup=kb)

    @bot.callback_query_handler(
        func=lambda c: c.data == "refresh_dashboard" and c.from_user.id in ADMIN_IDS + [OWNER_ID]
    )
    def refresh_dashboard(call):
        bot.answer_callback_query(call.id, "Actualizando...")
        bot.delete_message(call.message.chat.id, call.message.message_id)
        _send_dashboard(call.from_user.id, bot, db)

    # ── /mispagos (historial del usuario) ─────────────────────────────────────
    @bot.message_handler(commands=["mispagos"])
    def cmd_my_payments(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            return
        payments = db.get_user_payments(uid)
        if not payments:
            bot.send_message(uid, "No tienes pagos registrados.")
            return
        icons = {"approved": "✅", "rejected": "❌", "pending": "⏳"}
        lines = ["💳 *Historial de pagos*\n"]
        for p in payments:
            icon = icons.get(p["status"], "❓")
            fecha = p["requested_at"][:10]
            lines.append(f"{icon} {fecha} — {p['plan'].capitalize()} — {p['status']}")
        bot.send_message(uid, "\n".join(lines), parse_mode="Markdown")


def send_daily_report(bot, db):
    """Llamada desde el hilo de background cada 24h para enviar reporte al owner."""
    try:
        s = db.get_dashboard_stats()
        expiring = db.get_expiring_this_week()

        exp_lines = ""
        for u in expiring[:10]:
            exp_lines += f"  • @{u['username'] or u['user_id']} — vence {u['access_end'][:10]}\n"

        texto = (
            f"📈 *Reporte diario — {_today()}*\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"Suscriptores activos: {s['active']}\n"
            f"Aportadores: {s['contributors']}\n"
            f"Nuevos hoy: {s['new_today']}\n"
            f"Pagos aprobados hoy: {s['approved_today']}\n"
            f"Pagos pendientes: {s['pending_payments']}\n"
            f"Por vencer esta semana: {len(expiring)}\n"
        )
        if exp_lines:
            texto += f"\n⏰ *Por vencer:*\n{exp_lines}"

        bot.send_message(OWNER_ID, texto, parse_mode="Markdown")
        logger.info("Reporte diario enviado al owner.")
    except Exception as e:
        logger.error(f"Error en reporte diario: {e}")


def _today():
    from datetime import datetime
    return datetime.utcnow().strftime("%d/%m/%Y")
