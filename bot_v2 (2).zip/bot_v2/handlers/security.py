"""
security.py  –  Palabras prohibidas, mute y códigos de referido
"""

import logging
from telebot import types
from config import OWNER_ID, ADMIN_IDS, PLANS, BANNED_WORDS

logger = logging.getLogger("SecurityHandler")

_extra_banned_words = []


def contains_banned_word(text: str) -> bool:
    text_lower = text.lower()
    all_words = BANNED_WORDS + _extra_banned_words
    return any(w.lower() in text_lower for w in all_words)


def register_security_handlers(bot, db):

    @bot.message_handler(commands=["addpalabra"])
    def cmd_add_word(msg):
        uid = msg.from_user.id
        if uid not in ADMIN_IDS and uid != OWNER_ID:
            return
        parts = msg.text.split(maxsplit=1)
        if len(parts) < 2:
            sent = bot.send_message(uid, "✍️ Escribe la palabra a prohibir:")
            bot.register_next_step_handler(sent, lambda m: _do_add_word(m, uid))
            return
        _save_word(parts[1].strip().lower(), uid, bot, msg.chat.id)

    def _do_add_word(msg, admin_id):
        if msg.from_user.id not in ADMIN_IDS and msg.from_user.id != OWNER_ID:
            return
        _save_word(msg.text.strip().lower(), admin_id, bot, msg.chat.id)

    def _save_word(word, admin_id, bot, chat_id):
        if not word:
            bot.send_message(chat_id, "❌ Palabra vacía.")
            return
        all_words = BANNED_WORDS + _extra_banned_words
        if word in [w.lower() for w in all_words]:
            bot.send_message(chat_id, f"⚠️ `{word}` ya está en la lista.", parse_mode="Markdown")
            return
        _extra_banned_words.append(word)
        db.log_action(admin_id, "ADD_BANNED_WORD", details=word)
        bot.send_message(chat_id, f"✅ Palabra `{word}` agregada.", parse_mode="Markdown")

    @bot.message_handler(commands=["quitarpalabra"])
    def cmd_remove_word(msg):
        uid = msg.from_user.id
        if uid not in ADMIN_IDS and uid != OWNER_ID:
            return
        parts = msg.text.split(maxsplit=1)
        if len(parts) < 2:
            sent = bot.send_message(uid, "✍️ Escribe la palabra a quitar:")
            bot.register_next_step_handler(sent, lambda m: _do_remove_word(m, uid))
            return
        _remove_word(parts[1].strip().lower(), uid, bot, msg.chat.id)

    def _do_remove_word(msg, admin_id):
        _remove_word(msg.text.strip().lower(), admin_id, bot, msg.chat.id)

    def _remove_word(word, admin_id, bot, chat_id):
        if word in _extra_banned_words:
            _extra_banned_words.remove(word)
            db.log_action(admin_id, "REMOVE_BANNED_WORD", details=word)
            bot.send_message(chat_id, f"✅ `{word}` eliminada.", parse_mode="Markdown")
        elif word in [w.lower() for w in BANNED_WORDS]:
            bot.send_message(chat_id, f"⚠️ `{word}` está en config.py, edítalo manualmente.", parse_mode="Markdown")
        else:
            bot.send_message(chat_id, f"❌ `{word}` no está en la lista.", parse_mode="Markdown")

    @bot.message_handler(commands=["palabrasprohibidas"])
    def cmd_list_words(msg):
        uid = msg.from_user.id
        if uid not in ADMIN_IDS and uid != OWNER_ID:
            return
        all_words = BANNED_WORDS + _extra_banned_words
        if not all_words:
            bot.send_message(uid, "📭 No hay palabras prohibidas.")
            return
        lines = ["🚫 *Palabras prohibidas*\n"]
        for w in BANNED_WORDS:
            lines.append(f"• `{w}` _(config.py)_")
        for w in _extra_banned_words:
            lines.append(f"• `{w}` _(agregada desde bot)_")
        lines.append(f"\n_Total: {len(all_words)}_")
        bot.send_message(uid, "\n".join(lines), parse_mode="Markdown")

    @bot.message_handler(commands=["generarcodigo"])
    def cmd_gen_code(msg):
        if msg.from_user.id != OWNER_ID:
            return
        parts = msg.text.split()
        if len(parts) < 2 or parts[1] not in PLANS:
            kb = types.InlineKeyboardMarkup(row_width=1)
            for key, plan in PLANS.items():
                kb.add(types.InlineKeyboardButton(f"📅 {plan['label']}", callback_data=f"gencode_{key}"))
            bot.send_message(msg.chat.id, "¿Para qué plan?", reply_markup=kb)
            return
        _do_gen_code(msg.from_user.id, parts[1], bot, db)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("gencode_") and c.from_user.id == OWNER_ID)
    def cb_gen_code(call):
        bot.answer_callback_query(call.id)
        _do_gen_code(call.from_user.id, call.data[8:], bot, db)

    def _do_gen_code(owner_id, plan_key, bot, db):
        import secrets, string
        code = "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
        db.create_referral_code(code, plan_key, owner_id)
        plan = PLANS[plan_key]
        bot.send_message(
            owner_id,
            f"✅ *Código generado*\n\nCódigo: `{code}`\nPlan: *{plan['label']}* ({plan['days']} días)\n\nCompártelo — el usuario lo usa con /codigo",
            parse_mode="Markdown"
        )

    @bot.message_handler(commands=["miscodigos"])
    def cmd_my_codes(msg):
        if msg.from_user.id != OWNER_ID:
            return
        codes = db.list_referral_codes(OWNER_ID)
        if not codes:
            bot.send_message(msg.chat.id, "No tienes códigos generados.")
            return
        lines = ["🔑 *Tus códigos*\n"]
        for c in codes:
            estado = f"✅ Usado por `{c['used_by']}`" if c["used_by"] else "🟢 Disponible"
            lines.append(f"`{c['code']}` — {c['plan']} — {estado}")
        bot.send_message(msg.chat.id, "\n".join(lines), parse_mode="Markdown")

    @bot.message_handler(commands=["codigo"])
    def cmd_use_code(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            return
        db.upsert_user(uid, msg.from_user.username, msg.from_user.full_name)
        parts = msg.text.split()
        if len(parts) < 2:
            sent = bot.send_message(uid, "✍️ Escribe tu código de acceso:")
            bot.register_next_step_handler(sent, lambda m: _redeem(m, db, bot))
            return
        _redeem_text(uid, parts[1].strip(), msg, db, bot)

    def _redeem(msg, db, bot):
        _redeem_text(msg.from_user.id, msg.text.strip(), msg, db, bot)

    def _redeem_text(uid, code_input, msg, db, bot):
        if db.has_access(uid):
            bot.send_message(uid, "⚠️ Ya tienes suscripción activa.")
            return
        code_row = db.get_referral_code(code_input.upper())
        if not code_row:
            bot.send_message(uid, "❌ Código inválido o ya fue usado.")
            return
        plan_key = code_row["plan"]
        plan = PLANS.get(plan_key, {"label": plan_key, "days": 30})
        db.grant_access(uid, plan_key, plan["days"])
        db.use_referral_code(code_input, uid)
        db.log_action(OWNER_ID, "CODE_REDEEMED", uid, code_input.upper())
        from datetime import datetime, timedelta
        from config import WELCOME_APPROVED
        end  = (datetime.utcnow() + timedelta(days=plan["days"])).strftime("%Y-%m-%d")
        name = msg.from_user.full_name or msg.from_user.username or str(uid)
        bot.send_message(uid, WELCOME_APPROVED.format(name=name, plan=plan["label"], end=end), parse_mode="Markdown")
        try:
            bot.send_message(OWNER_ID, f"🔑 Código `{code_input.upper()}` canjeado por `{uid}` — Plan {plan['label']}", parse_mode="Markdown")
        except Exception:
            pass

    @bot.message_handler(commands=["silenciar"])
    def cmd_mute(msg):
        uid = msg.from_user.id
        if uid not in ADMIN_IDS and uid != OWNER_ID:
            return
        parts = msg.text.split()
        if len(parts) < 2:
            bot.send_message(uid, "Uso: /silenciar USER_ID [minutos]")
            return
        try:
            target  = int(parts[1])
            minutes = int(parts[2]) if len(parts) > 2 else 60
        except ValueError:
            bot.send_message(uid, "❌ Parámetros inválidos.")
            return
        db.mute_user(target, minutes)
        db.log_action(uid, "MUTE", target, f"{minutes} min")
        bot.send_message(uid, f"🔇 Usuario `{target}` silenciado por {minutes} minutos.", parse_mode="Markdown")
        try:
            bot.send_message(target, f"🔇 Fuiste silenciado por {minutes} minutos.")
        except Exception:
            pass

    @bot.message_handler(commands=["dessilenciar"])
    def cmd_unmute(msg):
        uid = msg.from_user.id
        if uid not in ADMIN_IDS and uid != OWNER_ID:
            return
        parts = msg.text.split()
        if len(parts) < 2:
            bot.send_message(uid, "Uso: /dessilenciar USER_ID")
            return
        try:
            target = int(parts[1])
        except ValueError:
            bot.send_message(uid, "❌ ID inválido.")
            return
        db.unmute_user(target)
        db.log_action(uid, "UNMUTE", target)
        bot.send_message(uid, f"🔊 Usuario `{target}` dessilenciado.", parse_mode="Markdown")
        try:
            bot.send_message(target, "🔊 Tu silencio fue levantado.")
        except Exception:
            pass
