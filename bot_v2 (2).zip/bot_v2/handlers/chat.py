"""
handlers/chat.py  –  Chat grupal interno
- Solo texto permitido (fotos, videos, archivos bloqueados)
- protect_content=True en todos los mensajes (bloquea reenvío y descarga)
- Palabras prohibidas
- Mute manual por admins
"""

import logging
from telebot import types
from config import ADMIN_IDS, OWNER_ID, GROUP_RULES
from handlers.security import contains_banned_word

logger = logging.getLogger("ChatHandler")

_pending_reply = {}


def register_chat_handlers(bot, db):

    # ── /chat ─────────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["chat"])
    def cmd_chat(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            return
        db.upsert_user(uid, msg.from_user.username, msg.from_user.full_name)
        if not db.has_access(uid):
            bot.send_message(uid, "🔒 No tienes acceso al chat. Usa /comprar.")
            return

        kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
        kb.add("💬 Enviar mensaje al chat", "📜 Ver últimos mensajes")
        kb.add("📌 Ver reglas", "🚪 Salir del chat")
        bot.send_message(
            uid,
            "💬 *Chat grupal privado*\n"
            "Solo miembros activos pueden participar.\n"
            "⚠️ Solo se permite texto. Fotos y archivos están bloqueados.",
            parse_mode="Markdown",
            reply_markup=kb,
            protect_content=True
        )

    # ── /reglas ───────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["reglas"])
    def cmd_reglas(msg):
        if db.is_banned(msg.from_user.id):
            return
        bot.send_message(
            msg.chat.id, GROUP_RULES,
            parse_mode="Markdown",
            protect_content=True
        )

    # ── Teclado ───────────────────────────────────────────────────────────────
    @bot.message_handler(func=lambda m: m.text == "📜 Ver últimos mensajes")
    def view_chat(msg):
        uid = msg.from_user.id
        if not db.has_access(uid) or db.is_banned(uid):
            return
        messages = db.get_recent_messages(20)
        if not messages:
            bot.send_message(uid, "📭 El chat está vacío.", protect_content=True)
            return
        lines = ["📜 *Últimos mensajes:*\n"]
        for m in reversed(messages):
            name  = m["full_name"] or m["username"] or str(m["user_id"])
            plan  = (m["plan"] or "").capitalize()
            count = m["purchase_count"]
            role  = m["role"]
            if role == "owner":
                header = f"👑 {name}"
            elif role == "admin":
                header = f"🛡️ {name}"
            elif role == "contributor":
                header = f"💎 {name}"
            elif plan and count > 0:
                header = f"👤 {name} ({plan} x{count})"
            elif plan:
                header = f"👤 {name} ({plan})"
            else:
                header = f"👤 {name}"
            lines.append(f"*{header}*\n{m['message']}\n")
        bot.send_message(uid, "\n".join(lines), parse_mode="Markdown", protect_content=True)

    @bot.message_handler(func=lambda m: m.text == "📌 Ver reglas")
    def view_rules(msg):
        if not db.has_access(msg.from_user.id) or db.is_banned(msg.from_user.id):
            return
        bot.send_message(msg.chat.id, GROUP_RULES, parse_mode="Markdown", protect_content=True)

    @bot.message_handler(func=lambda m: m.text == "🚪 Salir del chat")
    def leave_chat(msg):
        bot.send_message(msg.from_user.id, "👋 Saliste del chat.", reply_markup=types.ReplyKeyboardRemove())

    @bot.message_handler(func=lambda m: m.text == "💬 Enviar mensaje al chat")
    def prompt_send(msg):
        uid = msg.from_user.id
        if not db.has_access(uid) or db.is_banned(uid):
            return
        sent = bot.send_message(uid, "✍️ Escribe tu mensaje (solo texto):", protect_content=True)
        bot.register_next_step_handler(sent, _broadcast_chat_message)

    # ── Bloquear archivos, fotos, videos, audio, stickers ────────────────────
    @bot.message_handler(
        func=lambda m: m.chat.type == "private" and db.has_access(m.from_user.id),
        content_types=["photo", "video", "document", "audio", "voice",
                       "video_note", "sticker", "animation", "contact", "location"]
    )
    def block_media(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            return
        bot.send_message(
            uid,
            "🚫 *Solo se permite texto en el chat.*\n"
            "Fotos, archivos, videos y otros archivos están bloqueados por seguridad.",
            parse_mode="Markdown",
            protect_content=True
        )
        db.log_action(uid, "MEDIA_BLOCKED", uid, msg.content_type)
        logger.info(f"Media bloqueada de {uid}: {msg.content_type}")

    # ── Mensajes de texto libres ──────────────────────────────────────────────
    @bot.message_handler(
        func=lambda m: (
            m.chat.type == "private" and m.text
            and not m.text.startswith("/")
            and m.text not in ["💬 Enviar mensaje al chat", "📜 Ver últimos mensajes",
                                "📌 Ver reglas", "🚪 Salir del chat"]
        ),
        content_types=["text"]
    )
    def handle_free_text(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            return
        if db.has_access(uid):
            _broadcast_chat_message(msg)

    # ══ Broadcast ══════════════════════════════════════════════════════════════
    def _broadcast_chat_message(msg):
        uid = msg.from_user.id
        if not db.has_access(uid) or db.is_banned(uid):
            bot.send_message(uid, "🔒 Sin acceso al chat.", protect_content=True)
            return

        # Bloquear si intentó enviar algo que no es texto
        if not msg.text:
            bot.send_message(
                uid,
                "🚫 Solo se permite texto en el chat.",
                protect_content=True
            )
            return

        text = msg.text.strip()
        if not text:
            return

        # ── Mute activo ───────────────────────────────────────────────────────
        if db.is_muted(uid):
            bot.send_message(uid, "🔇 Estás silenciado en el chat.", protect_content=True)
            return

        # ── Palabras prohibidas ───────────────────────────────────────────────
        if contains_banned_word(text):
            bot.send_message(
                uid,
                "⛔ Tu mensaje contiene palabras no permitidas y no fue enviado.",
                protect_content=True
            )
            db.log_action(uid, "BANNED_WORD_BLOCKED", uid, text[:50])
            return

        db.upsert_user(uid, msg.from_user.username, msg.from_user.full_name)
        msg_id = db.save_message(uid, text)

        user           = db.get_user(uid)
        name           = user["full_name"] or user["username"] or str(uid)
        plan           = (user["plan"] or "").capitalize() if user else ""
        purchase_count = db.get_purchase_count(uid)
        role           = user["role"] if user else "subscriber"

        # Cabecera: Nombre (Plan xVeces)
        # Roles especiales muestran su título en vez del plan
        if role == "owner":
            header = f"👑 {name}"
        elif role == "admin":
            header = f"🛡️ {name}"
        elif role == "contributor":
            header = f"💎 {name}"
        elif plan and purchase_count > 0:
            header = f"👤 {name} ({plan} x{purchase_count})"
        elif plan:
            header = f"👤 {name} ({plan})"
        else:
            header = f"👤 {name}"

        display = f"*{header}*\n{text}"

        members = db.get_chat_subscribers()
        ok = fail = 0
        for row in members:
            if row["user_id"] == uid:
                continue
            try:
                kb = types.InlineKeyboardMarkup()
                kb.add(types.InlineKeyboardButton(
                    "↩️ Responder", callback_data=f"reply_{msg_id}_{uid}"
                ))
                bot.send_message(
                    row["user_id"], display,
                    parse_mode="Markdown",
                    reply_markup=kb,
                    protect_content=True   # ← bloquea reenvío y descarga
                )
                ok += 1
            except Exception:
                fail += 1

        bot.send_message(uid, "📨 Mensaje enviado.", protect_content=True)
        logger.info(f"Chat: {uid} → {ok} miembros")

    # ── Responder ─────────────────────────────────────────────────────────────
    @bot.callback_query_handler(func=lambda c: c.data.startswith("reply_"))
    def on_reply(call):
        uid = call.from_user.id
        if not db.has_access(uid) or db.is_banned(uid):
            bot.answer_callback_query(call.id, "Sin acceso.")
            return
        _, msg_id, orig_uid = call.data.split("_")
        _pending_reply[uid] = int(msg_id)
        bot.answer_callback_query(call.id)
        sent = bot.send_message(uid, "↩️ Escribe tu respuesta (solo texto):", protect_content=True)
        bot.register_next_step_handler(sent, lambda m: _send_reply(m, int(orig_uid), int(msg_id)))

    def _send_reply(msg, orig_uid, reply_to_id):
        uid = msg.from_user.id
        if not db.has_access(uid) or db.is_banned(uid):
            return
        if db.is_muted(uid):
            bot.send_message(uid, "🔇 Estás silenciado.", protect_content=True)
            return
        if not msg.text:
            bot.send_message(uid, "🚫 Solo se permite texto.", protect_content=True)
            return
        text = msg.text.strip()
        if contains_banned_word(text):
            bot.send_message(uid, "⛔ Tu respuesta contiene palabras no permitidas.", protect_content=True)
            return
        db.upsert_user(uid, msg.from_user.username, msg.from_user.full_name)
        db.save_message(uid, text, reply_to=reply_to_id)
        user  = db.get_user(uid)
        name  = user["full_name"] or user["username"] or str(uid)
        plan  = (user["plan"] or "").capitalize() if user else ""
        count = db.get_purchase_count(uid)
        role  = user["role"] if user else "subscriber"
        if role == "owner":
            header = f"👑 {name}"
        elif role == "admin":
            header = f"🛡️ {name}"
        elif role == "contributor":
            header = f"💎 {name}"
        elif plan and count > 0:
            header = f"👤 {name} ({plan} x{count})"
        else:
            header = f"👤 {name} ({plan})" if plan else f"👤 {name}"
        display = f"↩️ *{header}* respondió:\n{text}"
        for row in db.get_chat_subscribers():
            try:
                bot.send_message(
                    row["user_id"], display,
                    parse_mode="Markdown",
                    protect_content=True
                )
            except Exception:
                pass

    # ── Borrar mensaje (admins) ───────────────────────────────────────────────
    @bot.message_handler(commands=["delmsg"])
    def del_msg(msg):
        uid = msg.from_user.id
        if uid not in ADMIN_IDS and uid != OWNER_ID:
            return
        parts = msg.text.split()
        if len(parts) < 2:
            bot.send_message(uid, "Uso: /delmsg MSG_ID")
            return
        try:
            mid = int(parts[1])
            db.delete_message(mid)
            db.log_action(uid, "DELETE_CHAT_MSG", mid)
            bot.send_message(uid, f"🗑 Mensaje #{mid} eliminado.")
        except ValueError:
            bot.send_message(uid, "❌ ID inválido.")
