"""
handlers/admin.py  –  Panel de administración
"""

import logging
from telebot import types
from config import ADMIN_IDS, OWNER_ID, PLANS
from decorators import admin_only

logger = logging.getLogger("AdminHandler")


def register_admin_handlers(bot, db):

    @bot.message_handler(commands=["adminpanel"])
    @admin_only()
    def admin_panel(msg):
        db.upsert_user(msg.from_user.id, msg.from_user.username, msg.from_user.full_name)
        kb = types.InlineKeyboardMarkup(row_width=2)
        kb.add(
            types.InlineKeyboardButton("👥 Ver suscriptores",   callback_data="adm_subscribers"),
            types.InlineKeyboardButton("⏳ Pagos pendientes",   callback_data="adm_pending"),
            types.InlineKeyboardButton("🔨 Banear",             callback_data="adm_ban_prompt"),
            types.InlineKeyboardButton("🗑 Eliminar mensaje",   callback_data="adm_del_msg"),
            types.InlineKeyboardButton("📊 Stats aportes",      callback_data="adm_contrib_stats"),
        )
        bot.send_message(msg.chat.id, "🛡️ *Panel de Administración*", parse_mode="Markdown", reply_markup=kb)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("adm_") and c.from_user.id in ADMIN_IDS + [OWNER_ID])
    def admin_callbacks(call):
        db.upsert_user(call.from_user.id, call.from_user.username, call.from_user.full_name)

        if call.data == "adm_subscribers":
            users = db.list_users("subscriber")
            lines = [f"📋 *Suscriptores activos ({len(users)})*\n"]
            for u in users[:25]:
                end = u["access_end"][:10] if u["access_end"] else "—"
                lines.append(f"• `{u['user_id']}` @{u['username']} | {u['plan']} | hasta {end}")
            bot.answer_callback_query(call.id)
            bot.send_message(call.from_user.id, "\n".join(lines) or "Sin suscriptores.", parse_mode="Markdown")

        elif call.data == "adm_pending":
            payments = db.get_pending_payments()
            if not payments:
                bot.answer_callback_query(call.id, "Sin pagos pendientes ✅")
                return
            for p in payments:
                user = db.get_user(p["user_id"])
                bot.send_message(
                    call.from_user.id,
                    f"💳 Pago *#{p['id']}*\n`{p['user_id']}` @{user['username'] if user else '?'}\nPlan: {p['plan']}\nFecha: {p['requested_at']}",
                    parse_mode="Markdown"
                )
            bot.answer_callback_query(call.id)

        elif call.data == "adm_ban_prompt":
            bot.answer_callback_query(call.id)
            sent = bot.send_message(call.from_user.id, "✍️ ID del usuario a banear:")
            bot.register_next_step_handler(sent, lambda m: _adm_do_ban(m, call.from_user.id))

        elif call.data == "adm_contrib_stats":
            contributors = db.list_users("contributor")
            lines = ["📊 *Aportes hoy*\n"]
            for u in contributors:
                stats = db.get_contribution_stats(u["user_id"])
                lines.append(f"• @{u['username']} | Hoy: {stats['today']} | Total: {stats['total']}")
            bot.answer_callback_query(call.id)
            bot.send_message(call.from_user.id, "\n".join(lines) or "Sin aportadores.", parse_mode="Markdown")

    def _adm_do_ban(msg, admin_id):
        if admin_id not in ADMIN_IDS + [OWNER_ID]:
            return
        try:
            uid = int(msg.text.strip())
        except ValueError:
            bot.send_message(msg.chat.id, "❌ ID inválido.")
            return
        db.ban_user(uid, f"Baneado por admin {admin_id}")
        db.log_action(admin_id, "BAN", uid)
        bot.send_message(msg.chat.id, f"🔨 Usuario `{uid}` baneado.", parse_mode="Markdown")
        try:
            bot.send_message(uid, "🚫 Has sido baneado del bot.")
        except Exception:
            pass
