"""
handlers/user.py  –  Comandos generales + contacto al propietario + /ayuda completo
"""

import logging
from telebot import types
from config import OWNER_ID, WELCOME_MESSAGE

logger = logging.getLogger("UserHandler")

_talking_to_owner = set()


def register_user_handlers(bot, db):

    # ── /start ────────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["start"])
    def cmd_start(msg):
        uid = msg.from_user.id
        db.upsert_user(uid, msg.from_user.username, msg.from_user.full_name)

        if db.is_banned(uid):
            bot.send_message(uid, "🚫 Has sido baneado. Contacta al administrador si crees que es un error.")
            return

        user = db.get_user(uid)
        kb = types.InlineKeyboardMarkup(row_width=2)
        if db.has_access(uid):
            kb.add(
                types.InlineKeyboardButton("💬 Chat grupal",     callback_data="go_chat"),
                types.InlineKeyboardButton("📊 Mi suscripción",  callback_data="my_sub"),
            )
        else:
            kb.add(
                types.InlineKeyboardButton("💼 Ver planes",        callback_data="go_plans"),
                types.InlineKeyboardButton("📩 Hablar propietario", callback_data="talk_owner"),
            )

        plan_info = ""
        if user and user["access_end"]:
            plan_info = f"\n\n✅ Plan activo: *{user['plan']}* hasta `{user['access_end'][:10]}`"

        bot.send_message(uid, WELCOME_MESSAGE + plan_info, parse_mode="Markdown", reply_markup=kb)

    # ── Callbacks de /start ───────────────────────────────────────────────────
    @bot.callback_query_handler(func=lambda c: c.data in ("go_chat","my_sub","go_plans","talk_owner"))
    def start_callbacks(call):
        uid = call.from_user.id
        if db.is_banned(uid):
            bot.answer_callback_query(call.id, "Estás baneado.")
            return
        if call.data == "go_chat":
            bot.answer_callback_query(call.id)
            bot.send_message(uid, "👉 Usa /chat para acceder al chat grupal.")
        elif call.data == "my_sub":
            user = db.get_user(uid)
            if user and user["access_end"]:
                bot.answer_callback_query(call.id)
                bot.send_message(uid,
                    f"📋 *Tu suscripción*\nPlan: *{user['plan']}*\nExpira: `{user['access_end'][:16]}`\nRol: {user['role']}",
                    parse_mode="Markdown")
            else:
                bot.answer_callback_query(call.id, "Sin suscripción activa.")
        elif call.data == "go_plans":
            bot.answer_callback_query(call.id)
            bot.send_message(uid, "👉 Usa /comprar para ver los planes.")
        elif call.data == "talk_owner":
            bot.answer_callback_query(call.id)
            _talking_to_owner.add(uid)
            bot.send_message(uid,
                "📩 *Modo de contacto con el propietario*\nEscribe tu mensaje y lo recibirá directamente.\nUsa /cancelar para salir.",
                parse_mode="Markdown")

    # ── /propietario ──────────────────────────────────────────────────────────
    @bot.message_handler(commands=["propietario", "contactar"])
    def cmd_propietario(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            return
        db.upsert_user(uid, msg.from_user.username, msg.from_user.full_name)
        _talking_to_owner.add(uid)
        bot.send_message(uid,
            "📩 *Contacto con el propietario activado.*\nEscribe tu mensaje. Usa /cancelar para salir.",
            parse_mode="Markdown")

    # ── /cancelar ─────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["cancelar"])
    def cmd_cancelar(msg):
        uid = msg.from_user.id
        _talking_to_owner.discard(uid)
        bot.send_message(uid, "✅ Conversación cerrada.", reply_markup=types.ReplyKeyboardRemove())
        # Avisar al owner que el usuario cerró la conversación
        try:
            bot.send_message(OWNER_ID, f"ℹ️ Usuario `{uid}` cerró la conversación.", parse_mode="Markdown")
        except Exception:
            pass

    # ── Reenvío al propietario — conversación libre hasta aprobación ──────────
    @bot.message_handler(func=lambda m: m.chat.type == "private" and m.from_user.id in _talking_to_owner)
    def forward_to_owner(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            _talking_to_owner.discard(uid)
            return

        user = db.get_user(uid)
        name = (user["full_name"] if user else "") or msg.from_user.full_name or str(uid)

        # Solo mostrar el header la primera vez (si el mensaje anterior no era de esta sesión)
        header = (
            f"💬 *{name}* (`{uid}`) @{msg.from_user.username or '—'}\n"
            f"{'✅ Con acceso' if db.has_access(uid) else '🔒 Sin acceso aún'}\n"
            f"───────────────"
        )

        # Botones para el owner en cada mensaje
        kb = types.InlineKeyboardMarkup(row_width=2)
        kb.add(
            types.InlineKeyboardButton("↩️ Responder",     callback_data=f"ownerreply_{uid}"),
            types.InlineKeyboardButton("✅ Aprobar acceso", callback_data=f"quickgrant_{uid}"),
            types.InlineKeyboardButton("❌ Rechazar",       callback_data=f"quickreject_{uid}"),
        )

        try:
            bot.send_message(OWNER_ID, header, parse_mode="Markdown")
            bot.forward_message(OWNER_ID, msg.chat.id, msg.message_id)
            bot.send_message(OWNER_ID, "↕️ Acción rápida:", reply_markup=kb)
        except Exception as e:
            logger.error(f"Error reenviando al owner: {e}")

        # Confirmación discreta al usuario — sin mostrar nada de contadores
        bot.send_message(uid, "📨", protect_content=True)

    # ── Owner responde libremente ──────────────────────────────────────────────
    @bot.callback_query_handler(func=lambda c: c.data.startswith("ownerreply_") and c.from_user.id == OWNER_ID)
    def owner_reply_cb(call):
        target_uid = int(call.data.split("_")[1])
        bot.answer_callback_query(call.id)
        sent = bot.send_message(OWNER_ID, f"✍️ Escribe tu respuesta para `{target_uid}`:", parse_mode="Markdown")
        bot.register_next_step_handler(sent, lambda m: _send_owner_reply(m, target_uid))

    def _send_owner_reply(msg, target_uid):
        if msg.from_user.id != OWNER_ID:
            return
        try:
            bot.send_message(
                target_uid,
                f"👑 *Propietario:*\n\n{msg.text}",
                parse_mode="Markdown",
                protect_content=True
            )
            # El usuario sigue en la conversación automáticamente
            _talking_to_owner.add(target_uid)
        except Exception as e:
            bot.send_message(OWNER_ID, f"❌ Error enviando respuesta: {e}")

    # ── Owner aprueba acceso rápido desde la conversación ─────────────────────
    @bot.callback_query_handler(func=lambda c: c.data.startswith("quickgrant_") and c.from_user.id == OWNER_ID)
    def quick_grant(call):
        uid = int(call.data.split("_")[1])
        bot.answer_callback_query(call.id)

        # Pedir qué plan dar
        kb = types.InlineKeyboardMarkup(row_width=1)
        from config import PLANS
        for key, plan in PLANS.items():
            kb.add(types.InlineKeyboardButton(
                f"📅 {plan['label']} ({plan['days']} días)",
                callback_data=f"grantplan_{uid}_{key}"
            ))
        bot.send_message(OWNER_ID, f"¿Qué plan le das a `{uid}`?", parse_mode="Markdown", reply_markup=kb)

    @bot.callback_query_handler(func=lambda c: c.data.startswith("grantplan_") and c.from_user.id == OWNER_ID)
    def grant_plan(call):
        _, uid_str, plan_key = call.data.split("_", 2)
        uid = int(uid_str)
        from config import PLANS, WELCOME_APPROVED, GROUP_RULES
        from datetime import datetime, timedelta
        plan = PLANS.get(plan_key, {"label": plan_key, "days": 30})
        db.grant_access(uid, plan_key, plan["days"])
        db.log_action(OWNER_ID, "QUICK_GRANT", uid, plan_key)
        bot.answer_callback_query(call.id, "✅ Acceso otorgado")
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)

        # Sacar al usuario del modo conversación (ya tiene acceso)
        _talking_to_owner.discard(uid)

        user_info = db.get_user(uid)
        end  = (datetime.utcnow() + timedelta(days=plan["days"])).strftime("%Y-%m-%d")
        name = (user_info["full_name"] or user_info["username"] or str(uid)) if user_info else str(uid)
        try:
            bot.send_message(uid, WELCOME_APPROVED.format(name=name, plan=plan["label"], end=end), parse_mode="Markdown")
            bot.send_message(uid, GROUP_RULES, parse_mode="Markdown")
        except Exception:
            pass
        bot.send_message(OWNER_ID, f"✅ Acceso *{plan['label']}* otorgado a `{uid}`.", parse_mode="Markdown")

    # ── Owner rechaza ──────────────────────────────────────────────────────────
    @bot.callback_query_handler(func=lambda c: c.data.startswith("quickreject_") and c.from_user.id == OWNER_ID)
    def quick_reject(call):
        uid = int(call.data.split("_")[1])
        bot.answer_callback_query(call.id)
        bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)

        # El usuario puede seguir hablando para preguntar por qué
        try:
            bot.send_message(
                uid,
                "❌ Tu solicitud fue rechazada.\n"
                "Puedes seguir escribiendo si tienes alguna duda.",
                protect_content=True
            )
        except Exception:
            pass
        bot.send_message(OWNER_ID, f"❌ Rechazado `{uid}`. Sigue activa la conversación si quiere preguntar.")


    # ── /miaccess ─────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["miaccess", "miperfil"])
    def cmd_miaccess(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            bot.send_message(uid, "🚫 Estás baneado.")
            return
        db.upsert_user(uid, msg.from_user.username, msg.from_user.full_name)
        user = db.get_user(uid)
        if not user:
            bot.send_message(uid, "No tienes perfil registrado aún.")
            return
        acceso = "✅ Activo" if db.has_access(uid) else "❌ Sin acceso"
        bot.send_message(uid,
            f"👤 *Tu perfil*\nID: `{uid}`\nRol: {user['role']}\n"
            f"Plan: {user['plan'] or '—'}\nVence: {user['access_end'][:10] if user['access_end'] else '—'}\n"
            f"Estado: {acceso}",
            parse_mode="Markdown")

    # ── /mispagos ─────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["mispagos"])
    def cmd_mispagos(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            return
        db.upsert_user(uid, msg.from_user.username, msg.from_user.full_name)
        pagos = db.get_user_payments(uid)
        if not pagos:
            bot.send_message(uid, "No tienes pagos registrados aún.")
            return
        iconos = {"approved": "✅", "rejected": "❌", "pending": "⏳"}
        lines = ["💳 *Historial de pagos:*\n"]
        for p in pagos:
            ic = iconos.get(p["status"], "❓")
            fecha = p["requested_at"][:10]
            lines.append(f"{ic} {fecha} | *{p['plan']}* | {p['status']}")
        bot.send_message(uid, "\n".join(lines), parse_mode="Markdown")

    # ── /canjear (también en referral.py pero /ayuda lo menciona) ─────────────

    # ── /ayuda ────────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["ayuda", "help"])
    def cmd_ayuda(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            return
        db.upsert_user(uid, msg.from_user.username, msg.from_user.full_name)
        user = db.get_user(uid)
        role = user["role"] if user else "pending"

        texto = (
            "📋 *Comandos disponibles*\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "👤 *Generales*\n"
            "/start — Menú principal\n"
            "/ayuda — Ver esta lista\n"
            "/comprar — Ver planes y comprar\n"
            "/cancelarcompra — Cancelar compra en proceso\n"
            "/canjear [código] — Usar código de referido\n"
            "/propietario — Hablar con el dueño\n"
            "/cancelar — Salir del modo contacto\n"
            "/miaccess — Ver tu perfil y suscripción\n"
            "/mispagos — Ver tu historial de pagos\n"
        )

        if role in ("subscriber", "contributor", "admin", "owner"):
            texto += (
                "\n💬 *Chat grupal*\n"
                "/chat — Entrar al chat privado\n"
                "/reglas — Ver las reglas del grupo\n"
            )

        if role in ("contributor", "admin", "owner"):
            texto += (
                "\n💎 *Aportadores*\n"
                "/aportar — Registrar tu aporte del día\n"
                "/mistats — Ver tus estadísticas\n"
            )

        if role in ("admin", "owner"):
            texto += (
                "\n🛡️ *Administración*\n"
                "/adminpanel — Panel de administración\n"
                "/setcontributor [ID] — Hacer aportador\n"
                "/delmsg [ID] — Eliminar mensaje del chat\n"
                "/mute [ID] [min] — Silenciar usuario\n"
                "/unmute [ID] — Quitar silencio\n"
                "/palabras — Ver palabras prohibidas\n"
                "/stats — Dashboard de estadísticas\n"
                "/vencen — Ver quién vence esta semana\n"
                "/gencodigo [plan] — Generar código de referido\n"
                "/miscodigos — Ver códigos generados\n"
            )

        if role == "owner":
            texto += (
                "\n👑 *Propietario*\n"
                "/mipanel — Panel completo de control\n"
                "  ├ Ver todos los usuarios\n"
                "  ├ Aprobar / rechazar pagos\n"
                "  ├ Banear / desbanear usuarios\n"
                "  ├ Añadir admins\n"
                "  ├ Dar acceso manual\n"
                "  ├ Broadcast a todos\n"
                "  └ Audit log de acciones\n"
            )

        texto += "\n━━━━━━━━━━━━━━━━━━━━━━\n"
        iconos_rol = {
            "owner": "👑 Propietario", "admin": "🛡️ Administrador",
            "contributor": "💎 Aportador", "subscriber": "✅ Suscriptor activo",
            "pending": "🔒 Sin suscripción", "banned": "🚫 Baneado",
        }
        texto += f"_Tu rol: {iconos_rol.get(role, role)}_"
        bot.send_message(uid, texto, parse_mode="Markdown")
