"""
handlers/contributor.py  –  Lógica de aportadores
- Solo pueden ver y aportar
- Mínimo 1 000 diarios o se les banea automáticamente
"""

import logging
from telebot import types
from config import OWNER_ID, ADMIN_IDS, DAILY_MIN_CONTRIBUTION
from decorators import admin_only

logger = logging.getLogger("ContributorHandler")


def register_contributor_handlers(bot, db):

    # ── /aportar ──────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["aportar"])
    def cmd_aportar(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            return

        user = db.get_user(uid)
        if not user or user["role"] != "contributor":
            bot.send_message(uid, "❌ Solo los aportadores pueden usar este comando.")
            return

        sent = bot.send_message(
            uid,
            f"💰 *Registrar aporte*\n"
            f"Mínimo diario: {DAILY_MIN_CONTRIBUTION:,}\n\n"
            f"Escribe la cantidad que vas a aportar hoy:",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(sent, lambda m: _register_contribution(m, uid))

    def _register_contribution(msg, uid):
        if db.is_banned(uid):
            return
        try:
            amount = int(msg.text.strip().replace(",", "").replace(".", ""))
            if amount <= 0:
                raise ValueError
        except ValueError:
            bot.send_message(uid, "❌ Cantidad inválida. Ingresa un número entero positivo.")
            return

        db.add_contribution(uid, amount)
        stats = db.get_contribution_stats(uid)
        today  = stats["today"]
        total  = stats["total"]
        status = "✅" if today >= DAILY_MIN_CONTRIBUTION else "⚠️"

        bot.send_message(
            uid,
            f"💎 *Aporte registrado*: {amount:,}\n"
            f"Hoy: {today:,} {status}\n"
            f"Total acumulado: {total:,}\n\n"
            f"{'✅ Cumpliste el mínimo de hoy.' if today >= DAILY_MIN_CONTRIBUTION else f'⚠️ Te faltan {DAILY_MIN_CONTRIBUTION - today:,} para el mínimo de hoy.'}",
            parse_mode="Markdown"
        )
        logger.info(f"Aportador {uid} registró {amount} (hoy: {today})")

    # ── /mistats ──────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["mistats"])
    def cmd_mistats(msg):
        uid = msg.from_user.id
        if db.is_banned(uid):
            return

        user = db.get_user(uid)
        if not user or user["role"] != "contributor":
            bot.send_message(uid, "❌ Solo para aportadores.")
            return

        stats = db.get_contribution_stats(uid)
        today  = stats["today"] or 0
        total  = stats["total"] or 0
        count  = stats["count"] or 0
        status = "✅ Cumpliste" if today >= DAILY_MIN_CONTRIBUTION else f"⚠️ Faltan {DAILY_MIN_CONTRIBUTION - today:,}"

        bot.send_message(
            uid,
            f"📊 *Mis estadísticas de aportes*\n\n"
            f"Hoy: {today:,} — {status}\n"
            f"Total histórico: {total:,}\n"
            f"Número de aportes: {count}\n"
            f"Mínimo diario requerido: {DAILY_MIN_CONTRIBUTION:,}",
            parse_mode="Markdown"
        )

    # ── Admin: convertir usuario en aportador ─────────────────────────────────
    @bot.message_handler(commands=["setcontributor"])
    def cmd_set_contributor(msg):
        uid = msg.from_user.id
        if uid not in ADMIN_IDS and uid != OWNER_ID:
            return
        parts = msg.text.split()
        if len(parts) < 2:
            bot.send_message(uid, "Uso: /setcontributor USER_ID")
            return
        try:
            target = int(parts[1])
        except ValueError:
            bot.send_message(uid, "❌ ID inválido.")
            return

        db.upsert_user(target, "", "")
        db.set_role(target, "contributor")
        db.log_action(uid, "SET_CONTRIBUTOR", target)
        bot.send_message(uid, f"✅ `{target}` es ahora aportador.", parse_mode="Markdown")
        try:
            bot.send_message(
                target,
                f"💎 *Eres ahora un Aportador.*\n\n"
                f"Debes aportar mínimo *{DAILY_MIN_CONTRIBUTION:,}* diarios.\n"
                f"Usa /aportar para registrar tu aporte y /mistats para ver tu progreso.\n\n"
                f"⚠️ Si no cumples el mínimo serás baneado automáticamente.",
                parse_mode="Markdown"
            )
        except Exception:
            pass
