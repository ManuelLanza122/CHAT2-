"""
handlers/owner.py  –  Comandos exclusivos del propietario
"""

import logging
from telebot import types
from config import OWNER_ID, PLANS
from decorators import owner_only

logger = logging.getLogger("OwnerHandler")


def register_owner_handlers(bot, db):

    # ── /mipanel  ─────────────────────────────────────────────────────────────
    @bot.message_handler(commands=["mipanel"])
    @owner_only()
    def owner_panel(msg):
        kb = types.InlineKeyboardMarkup(row_width=2)
        kb.add(
            types.InlineKeyboardButton("👥 Ver usuarios",      callback_data="ow_list_users"),
            types.InlineKeyboardButton("⏳ Pagos pendientes",  callback_data="ow_pending"),
            types.InlineKeyboardButton("🔨 Banear usuario",    callback_data="ow_ban_prompt"),
            types.InlineKeyboardButton("✅ Desbanear",         callback_data="ow_unban_prompt"),
            types.InlineKeyboardButton("➕ Añadir admin",      callback_data="ow_add_admin"),
            types.InlineKeyboardButton("📋 Audit log",         callback_data="ow_audit"),
            types.InlineKeyboardButton("📢 Broadcast",         callback_data="ow_broadcast"),
            types.InlineKeyboardButton("🎁 Dar acceso manual", callback_data="ow_grant"),
        )
        bot.send_message(msg.chat.id, "👑 *Panel del Propietario*", parse_mode="Markdown", reply_markup=kb)

    # ── Callbacks del panel ────────────────────────────────────────────────────
    @bot.callback_query_handler(func=lambda c: c.data.startswith("ow_") and c.from_user.id == OWNER_ID)
    def owner_callbacks(call):
        db.upsert_user(call.from_user.id, call.from_user.username, call.from_user.full_name)

        # ── Lista de usuarios ──────────────────────────────────────────────────
        if call.data == "ow_list_users":
            users = db.list_users()
            lines = [f"👥 *Usuarios registrados ({len(users)})*\n"]
            for u in users[:30]:
                icon = "🔴" if u["banned"] else "🟢"
                end  = u["access_end"][:10] if u["access_end"] else "—"
                lines.append(f"{icon} `{u['user_id']}` @{u['username']} | {u['role']} | hasta {end}")
            bot.answer_callback_query(call.id)
            bot.send_message(call.from_user.id, "\n".join(lines), parse_mode="Markdown")

        # ── Pagos pendientes ───────────────────────────────────────────────────
        elif call.data == "ow_pending":
            payments = db.get_pending_payments()
            if not payments:
                bot.answer_callback_query(call.id, "No hay pagos pendientes ✅")
                return
            for p in payments:
                user = db.get_user(p["user_id"])
                kb = types.InlineKeyboardMarkup()
                kb.add(
                    types.InlineKeyboardButton("✅ Aprobar", callback_data=f"approve_{p['id']}"),
                    types.InlineKeyboardButton("❌ Rechazar", callback_data=f"reject_{p['id']}"),
                )
                bot.send_message(
                    call.from_user.id,
                    f"💳 Pago *#{p['id']}*\n"
                    f"Usuario: `{p['user_id']}` @{user['username'] if user else '?'}\n"
                    f"Plan: *{p['plan']}*\n"
                    f"Solicitado: {p['requested_at']}",
                    parse_mode="Markdown",
                    reply_markup=kb
                )
            bot.answer_callback_query(call.id)

        # ── Audit log ──────────────────────────────────────────────────────────
        elif call.data == "ow_audit":
            logs = db.get_audit_log(20)
            lines = ["📋 *Últimas acciones*\n"]
            for l in logs:
                lines.append(f"`{l['done_at'][:16]}` [{l['actor_id']}] {l['action']} → {l['target_id']} {l['details']}")
            bot.answer_callback_query(call.id)
            bot.send_message(call.from_user.id, "\n".join(lines) or "Sin registros.", parse_mode="Markdown")

        # ── Broadcast ──────────────────────────────────────────────────────────
        elif call.data == "ow_broadcast":
            bot.answer_callback_query(call.id)
            sent = bot.send_message(call.from_user.id, "✍️ Escribe el mensaje a enviar a todos los usuarios con acceso:")
            bot.register_next_step_handler(sent, _do_broadcast)

        # ── Dar acceso manual ──────────────────────────────────────────────────
        elif call.data == "ow_grant":
            bot.answer_callback_query(call.id)
            sent = bot.send_message(call.from_user.id, "✍️ Escribe: `USER_ID PLAN` (ej: 123456 mensual)")
            bot.register_next_step_handler(sent, _do_grant)

        # ── Ban prompt ─────────────────────────────────────────────────────────
        elif call.data == "ow_ban_prompt":
            bot.answer_callback_query(call.id)
            sent = bot.send_message(call.from_user.id, "✍️ Escribe el USER_ID a banear:")
            bot.register_next_step_handler(sent, _do_ban)

        # ── Unban prompt ───────────────────────────────────────────────────────
        elif call.data == "ow_unban_prompt":
            bot.answer_callback_query(call.id)
            sent = bot.send_message(call.from_user.id, "✍️ Escribe el USER_ID a desbanear:")
            bot.register_next_step_handler(sent, _do_unban)

        # ── Añadir admin ───────────────────────────────────────────────────────
        elif call.data == "ow_add_admin":
            bot.answer_callback_query(call.id)
            sent = bot.send_message(call.from_user.id, "✍️ Escribe el USER_ID al que dar rol de admin:")
            bot.register_next_step_handler(sent, _do_add_admin)

    # ── Aprobar / rechazar pago ────────────────────────────────────────────────
    @bot.callback_query_handler(func=lambda c: (c.data.startswith("approve_") or c.data.startswith("reject_")) and c.from_user.id == OWNER_ID)
    def handle_payment_decision(call):
        action, pid_str = call.data.split("_", 1)
        payment_id = int(pid_str)
        payment = db.get_payment(payment_id)
        if not payment:
            bot.answer_callback_query(call.id, "Pago no encontrado.")
            return

        if action == "approve":
            plan_cfg = PLANS.get(payment["plan"], {"days": 30})
            db.grant_access(payment["user_id"], payment["plan"], plan_cfg["days"])
            db.update_payment_status(payment_id, "approved", call.from_user.id)
            db.log_action(call.from_user.id, "PAYMENT_APPROVED", payment["user_id"], payment["plan"])
            try:
                bot.send_message(
                    payment["user_id"],
                    f"✅ ¡Tu pago fue aprobado! Plan *{payment['plan']}* activado.\n"
                    f"Usa /chat para acceder al grupo.",
                    parse_mode="Markdown"
                )
            except Exception:
                pass
            bot.answer_callback_query(call.id, "✅ Pago aprobado")
            bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)

        else:
            db.update_payment_status(payment_id, "rejected", call.from_user.id)
            db.log_action(call.from_user.id, "PAYMENT_REJECTED", payment["user_id"], "")
            try:
                bot.send_message(
                    payment["user_id"],
                    "❌ Tu pago fue rechazado. Contacta al propietario para más información."
                )
            except Exception:
                pass
            bot.answer_callback_query(call.id, "❌ Pago rechazado")
            bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)

    # ── Mensajes directos al owner (/comprar los reenvía) ─────────────────────
    # Esto se maneja en user.py; aquí el owner responde normalmente.

    # ══ Helpers ═══════════════════════════════════════════════════════════════
    def _do_broadcast(msg):
        if msg.from_user.id != OWNER_ID:
            return
        subscribers = db.get_chat_subscribers()
        ok = fail = 0
        for row in subscribers:
            try:
                bot.copy_message(row["user_id"], msg.chat.id, msg.message_id)
                ok += 1
            except Exception:
                fail += 1
        db.log_action(OWNER_ID, "BROADCAST", details=f"ok={ok} fail={fail}")
        bot.send_message(msg.chat.id, f"📢 Broadcast enviado: ✅ {ok} / ❌ {fail}")

    def _do_grant(msg):
        if msg.from_user.id != OWNER_ID:
            return
        try:
            parts = msg.text.strip().split()
            uid, plan = int(parts[0]), parts[1].lower()
            assert plan in PLANS
        except Exception:
            bot.send_message(msg.chat.id, "❌ Formato inválido. Usa: `USER_ID PLAN`", parse_mode="Markdown")
            return
        db.upsert_user(uid, "", "")
        db.grant_access(uid, plan, PLANS[plan]["days"])
        db.log_action(OWNER_ID, "MANUAL_GRANT", uid, plan)
        bot.send_message(msg.chat.id, f"✅ Acceso *{plan}* otorgado a `{uid}`.", parse_mode="Markdown")
        try:
            bot.send_message(uid, f"🎉 El propietario te dio acceso *{plan}*. Usa /chat.", parse_mode="Markdown")
        except Exception:
            pass

    def _do_ban(msg):
        if msg.from_user.id != OWNER_ID:
            return
        try:
            uid = int(msg.text.strip())
        except ValueError:
            bot.send_message(msg.chat.id, "❌ ID inválido.")
            return
        db.ban_user(uid, "Baneado por el propietario")
        db.log_action(OWNER_ID, "BAN", uid)
        bot.send_message(msg.chat.id, f"🔨 Usuario `{uid}` baneado.", parse_mode="Markdown")

    def _do_unban(msg):
        if msg.from_user.id != OWNER_ID:
            return
        try:
            uid = int(msg.text.strip())
        except ValueError:
            bot.send_message(msg.chat.id, "❌ ID inválido.")
            return
        db.unban_user(uid)
        db.log_action(OWNER_ID, "UNBAN", uid)
        bot.send_message(msg.chat.id, f"✅ Usuario `{uid}` desbaneado.", parse_mode="Markdown")

    def _do_add_admin(msg):
        if msg.from_user.id != OWNER_ID:
            return
        try:
            uid = int(msg.text.strip())
        except ValueError:
            bot.send_message(msg.chat.id, "❌ ID inválido.")
            return
        db.set_role(uid, "admin")
        if uid not in ADMIN_IDS:
            ADMIN_IDS.append(uid)
        db.log_action(OWNER_ID, "ADD_ADMIN", uid)
        bot.send_message(msg.chat.id, f"✅ `{uid}` ahora es admin.", parse_mode="Markdown")
        try:
            bot.send_message(uid, "🛡️ Eres ahora administrador del bot. Usa /adminpanel.")
        except Exception:
            pass
