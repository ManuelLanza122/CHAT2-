import telebot
import logging
import time
import threading
from config import BOT_TOKEN, OWNER_ID, RENEW_ALERT_MSG, PLANS
from database import Database

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.FileHandler("bot.log"), logging.StreamHandler()]
)
logger = logging.getLogger("MainBot")

bot = telebot.TeleBot(BOT_TOKEN, threaded=True, num_threads=8)
db  = Database()


def check_expired_subscriptions():
    while True:
        try:
            for user in db.get_expired_users():
                db.revoke_access(user["user_id"])
                try:
                    bot.send_message(user["user_id"], "⚠️ Tu suscripción ha vencido.\nUsa /comprar para renovar.")
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"check_expired: {e}")
        time.sleep(3600)


def check_renew_alerts():
    while True:
        try:
            for user in db.get_users_expiring_soon():
                uid  = user["user_id"]
                plan = PLANS.get(user["plan"], {"label": user["plan"]})
                end  = user["access_end"][:10]
                kb = telebot.types.InlineKeyboardMarkup()
                kb.add(telebot.types.InlineKeyboardButton("🔄 Renovar ahora", callback_data=f"buy_{user['plan']}"))
                try:
                    bot.send_message(uid, RENEW_ALERT_MSG.format(plan=plan["label"], end=end),
                                     parse_mode="Markdown", reply_markup=kb)
                    db.mark_renew_alerted(uid)
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"check_renew: {e}")
        time.sleep(3600)


def check_contributor_activity():
    while True:
        try:
            for user in db.get_inactive_contributors():
                db.ban_user(user["user_id"], "Inactividad como aportador")
                try:
                    bot.send_message(user["user_id"], "🚫 Fuiste baneado por no cumplir el aporte mínimo diario.")
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"check_contributors: {e}")
        time.sleep(86400)


def daily_report():
    while True:
        time.sleep(86400)
        try:
            from handlers.stats import send_daily_report
            send_daily_report(bot, db)
        except Exception as e:
            logger.error(f"daily_report: {e}")


if __name__ == "__main__":
    db.init_db()

    from handlers.owner       import register_owner_handlers
    from handlers.admin       import register_admin_handlers
    from handlers.payment     import register_payment_handlers
    from handlers.chat        import register_chat_handlers
    from handlers.contributor import register_contributor_handlers
    from handlers.user        import register_user_handlers
    from handlers.security    import register_security_handlers
    from handlers.stats       import register_stats_handlers

    register_owner_handlers(bot, db)
    register_admin_handlers(bot, db)
    register_payment_handlers(bot, db)
    register_chat_handlers(bot, db)
    register_contributor_handlers(bot, db)
    register_user_handlers(bot, db)
    register_security_handlers(bot, db)
    register_stats_handlers(bot, db)

    threading.Thread(target=check_expired_subscriptions, daemon=True).start()
    threading.Thread(target=check_renew_alerts,          daemon=True).start()
    threading.Thread(target=check_contributor_activity,  daemon=True).start()
    threading.Thread(target=daily_report,                daemon=True).start()

    logger.info("✅ Bot iniciado.")
    bot.infinity_polling(timeout=30, long_polling_timeout=30)
