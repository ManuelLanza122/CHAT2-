"""
decorators.py  –  Guards de seguridad reutilizables
"""
from functools import wraps
from config import OWNER_ID, ADMIN_IDS


def _get_uid(obj):
    try:
        return obj.from_user.id
    except AttributeError:
        return obj.message.from_user.id


def owner_only():
    def decorator(func):
        @wraps(func)
        def wrapper(obj, *args, **kwargs):
            if _get_uid(obj) != OWNER_ID:
                return
            return func(obj, *args, **kwargs)
        return wrapper
    return decorator


def admin_only():
    def decorator(func):
        @wraps(func)
        def wrapper(obj, *args, **kwargs):
            if _get_uid(obj) not in ADMIN_IDS and _get_uid(obj) != OWNER_ID:
                return
            return func(obj, *args, **kwargs)
        return wrapper
    return decorator
