"""
database.py  –  Capa de datos SQLite local
"""

import sqlite3
import logging
from datetime import datetime, timedelta
from config import DB_PATH, DAILY_MIN_CONTRIBUTION, RENEW_ALERT_DAYS

logger = logging.getLogger("Database")


class Database:
    def __init__(self):
        self.path = DB_PATH

    def _connect(self):
        conn = sqlite3.connect(self.path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    # ══════════════════════════════════════════════════════════════════════════
    #  INICIALIZACIÓN
    # ══════════════════════════════════════════════════════════════════════════
    def init_db(self):
        with self._connect() as conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                user_id       INTEGER PRIMARY KEY,
                username      TEXT,
                full_name     TEXT,
                role          TEXT DEFAULT 'pending',
                plan          TEXT,
                access_start  DATETIME,
                access_end    DATETIME,
                banned        INTEGER DEFAULT 0,
                ban_reason    TEXT,
                muted_until   DATETIME,
                renew_alerted INTEGER DEFAULT 0,
                created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS payments (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id        INTEGER REFERENCES users(user_id),
                plan           TEXT,
                status         TEXT DEFAULT 'pending',
                channel_msg_id INTEGER,
                requested_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
                reviewed_at    DATETIME,
                reviewed_by    INTEGER
            );

            CREATE TABLE IF NOT EXISTS chat_messages (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id  INTEGER REFERENCES users(user_id),
                message  TEXT,
                reply_to INTEGER,
                sent_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
                deleted  INTEGER DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS contributions (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id        INTEGER REFERENCES users(user_id),
                amount         INTEGER,
                contributed_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS audit_log (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                actor_id  INTEGER,
                action    TEXT,
                target_id INTEGER,
                details   TEXT,
                done_at   DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS referral_codes (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                code       TEXT UNIQUE,
                plan       TEXT,
                created_by INTEGER,
                used_by    INTEGER,
                used_at    DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS muted_users (
                user_id    INTEGER PRIMARY KEY,
                muted_until DATETIME,
                reason     TEXT
            );
            """)
        logger.info("Base de datos inicializada.")

    # ══════════════════════════════════════════════════════════════════════════
    #  USUARIOS
    # ══════════════════════════════════════════════════════════════════════════
    def get_user(self, user_id):
        with self._connect() as conn:
            return conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()

    def upsert_user(self, user_id, username, full_name):
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO users (user_id, username, full_name)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    username=excluded.username,
                    full_name=excluded.full_name
            """, (user_id, username or "", full_name or ""))

    def set_role(self, user_id, role):
        with self._connect() as conn:
            conn.execute("UPDATE users SET role=? WHERE user_id=?", (role, user_id))

    def grant_access(self, user_id, plan, days):
        now = datetime.utcnow()
        end = now + timedelta(days=days)
        with self._connect() as conn:
            conn.execute("""
                UPDATE users SET role='subscriber', plan=?, access_start=?,
                access_end=?, banned=0, renew_alerted=0
                WHERE user_id=?
            """, (plan, now.isoformat(), end.isoformat(), user_id))

    def revoke_access(self, user_id):
        with self._connect() as conn:
            conn.execute(
                "UPDATE users SET role='pending', plan=NULL, access_end=NULL WHERE user_id=?",
                (user_id,)
            )

    def ban_user(self, user_id, reason=""):
        with self._connect() as conn:
            conn.execute(
                "UPDATE users SET banned=1, ban_reason=?, role='banned' WHERE user_id=?",
                (reason, user_id)
            )

    def unban_user(self, user_id):
        with self._connect() as conn:
            conn.execute(
                "UPDATE users SET banned=0, ban_reason=NULL, role='pending' WHERE user_id=?",
                (user_id,)
            )

    def is_banned(self, user_id):
        user = self.get_user(user_id)
        return bool(user and user["banned"])

    def has_access(self, user_id):
        user = self.get_user(user_id)
        if not user or user["banned"]:
            return False
        if user["role"] in ("admin", "owner", "contributor"):
            return True
        if user["role"] == "subscriber" and user["access_end"]:
            return datetime.utcnow() < datetime.fromisoformat(user["access_end"])
        return False

    def get_expired_users(self):
        with self._connect() as conn:
            return conn.execute("""
                SELECT * FROM users
                WHERE role='subscriber' AND access_end IS NOT NULL
                  AND access_end < datetime('now') AND banned=0
            """).fetchall()

    def list_users(self, role=None):
        with self._connect() as conn:
            if role:
                return conn.execute(
                    "SELECT * FROM users WHERE role=? ORDER BY created_at DESC", (role,)
                ).fetchall()
            return conn.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall()

    # ══════════════════════════════════════════════════════════════════════════
    #  MUTE (silencio en el chat)
    # ══════════════════════════════════════════════════════════════════════════
    def mute_user(self, user_id, minutes):
        until = (datetime.utcnow() + timedelta(minutes=minutes)).isoformat()
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO muted_users (user_id, muted_until, reason)
                VALUES (?, ?, 'spam')
                ON CONFLICT(user_id) DO UPDATE SET muted_until=excluded.muted_until
            """, (user_id, until))

    def unmute_user(self, user_id):
        with self._connect() as conn:
            conn.execute("DELETE FROM muted_users WHERE user_id=?", (user_id,))

    def is_muted(self, user_id):
        with self._connect() as conn:
            row = conn.execute(
                "SELECT muted_until FROM muted_users WHERE user_id=?", (user_id,)
            ).fetchone()
        if not row:
            return False
        return datetime.utcnow() < datetime.fromisoformat(row["muted_until"])

    # ══════════════════════════════════════════════════════════════════════════
    #  RENOVACIÓN
    # ══════════════════════════════════════════════════════════════════════════
    def get_users_expiring_soon(self):
        """Usuarios que vencen en RENEW_ALERT_DAYS días y aún no fueron alertados."""
        limit = (datetime.utcnow() + timedelta(days=RENEW_ALERT_DAYS)).isoformat()
        with self._connect() as conn:
            return conn.execute("""
                SELECT * FROM users
                WHERE role='subscriber' AND renew_alerted=0
                  AND access_end IS NOT NULL AND access_end <= ?
                  AND access_end > datetime('now') AND banned=0
            """, (limit,)).fetchall()

    def mark_renew_alerted(self, user_id):
        with self._connect() as conn:
            conn.execute(
                "UPDATE users SET renew_alerted=1 WHERE user_id=?", (user_id,)
            )

    # ══════════════════════════════════════════════════════════════════════════
    #  PAGOS
    # ══════════════════════════════════════════════════════════════════════════
    def create_payment(self, user_id, plan, channel_msg_id=None):
        with self._connect() as conn:
            cur = conn.execute("""
                INSERT INTO payments (user_id, plan, channel_msg_id) VALUES (?, ?, ?)
            """, (user_id, plan, channel_msg_id))
            return cur.lastrowid

    def get_payment(self, payment_id):
        with self._connect() as conn:
            return conn.execute("SELECT * FROM payments WHERE id=?", (payment_id,)).fetchone()

    def update_payment_status(self, payment_id, status, reviewer_id):
        with self._connect() as conn:
            conn.execute("""
                UPDATE payments SET status=?, reviewed_at=datetime('now'), reviewed_by=?
                WHERE id=?
            """, (status, reviewer_id, payment_id))

    def get_pending_payments(self):
        with self._connect() as conn:
            return conn.execute(
                "SELECT * FROM payments WHERE status='pending' ORDER BY requested_at"
            ).fetchall()

    def get_user_payments(self, user_id):
        with self._connect() as conn:
            return conn.execute("""
                SELECT * FROM payments WHERE user_id=? ORDER BY requested_at DESC LIMIT 10
            """, (user_id,)).fetchall()

    # ══════════════════════════════════════════════════════════════════════════
    #  ESTADÍSTICAS / DASHBOARD
    # ══════════════════════════════════════════════════════════════════════════
    def get_dashboard_stats(self):
        with self._connect() as conn:
            total       = conn.execute("SELECT COUNT(*) as n FROM users WHERE banned=0").fetchone()["n"]
            active      = conn.execute("""
                SELECT COUNT(*) as n FROM users
                WHERE role='subscriber' AND access_end > datetime('now') AND banned=0
            """).fetchone()["n"]
            contributors = conn.execute(
                "SELECT COUNT(*) as n FROM users WHERE role='contributor' AND banned=0"
            ).fetchone()["n"]
            expiring    = conn.execute(f"""
                SELECT COUNT(*) as n FROM users
                WHERE role='subscriber' AND banned=0
                  AND access_end BETWEEN datetime('now') AND datetime('now','+{RENEW_ALERT_DAYS} days')
            """).fetchone()["n"]
            new_today   = conn.execute("""
                SELECT COUNT(*) as n FROM users WHERE date(created_at)=date('now')
            """).fetchone()["n"]
            approved_today = conn.execute("""
                SELECT COUNT(*) as n FROM payments
                WHERE status='approved' AND date(reviewed_at)=date('now')
            """).fetchone()["n"]
            pending_pay = conn.execute(
                "SELECT COUNT(*) as n FROM payments WHERE status='pending'"
            ).fetchone()["n"]
            by_plan     = conn.execute("""
                SELECT plan, COUNT(*) as n FROM users
                WHERE role='subscriber' AND access_end > datetime('now') AND banned=0
                GROUP BY plan
            """).fetchall()

        return {
            "total": total,
            "active": active,
            "contributors": contributors,
            "expiring": expiring,
            "new_today": new_today,
            "approved_today": approved_today,
            "pending_payments": pending_pay,
            "by_plan": {r["plan"]: r["n"] for r in by_plan},
        }

    def get_expiring_this_week(self):
        with self._connect() as conn:
            return conn.execute("""
                SELECT * FROM users
                WHERE role='subscriber' AND banned=0
                  AND access_end BETWEEN datetime('now') AND datetime('now','+7 days')
                ORDER BY access_end
            """).fetchall()

    # ══════════════════════════════════════════════════════════════════════════
    #  CHAT
    # ══════════════════════════════════════════════════════════════════════════
    def save_message(self, user_id, message, reply_to=None):
        with self._connect() as conn:
            cur = conn.execute("""
                INSERT INTO chat_messages (user_id, message, reply_to) VALUES (?, ?, ?)
            """, (user_id, message, reply_to))
            return cur.lastrowid

    def get_purchase_count(self, user_id):
        """Cuántas veces ha comprado (pagos aprobados)."""
        with self._connect() as conn:
            row = conn.execute("""
                SELECT COUNT(*) as n FROM payments
                WHERE user_id=? AND status='approved'
            """, (user_id,)).fetchone()
            return row["n"] if row else 0

    def get_recent_messages(self, limit=50):
        with self._connect() as conn:
            return conn.execute("""
                SELECT cm.*, u.username, u.full_name, u.role, u.plan,
                       (SELECT COUNT(*) FROM payments p
                        WHERE p.user_id=u.user_id AND p.status='approved') as purchase_count
                FROM chat_messages cm
                JOIN users u ON cm.user_id=u.user_id
                WHERE cm.deleted=0
                ORDER BY cm.sent_at DESC LIMIT ?
            """, (limit,)).fetchall()

    def delete_message(self, msg_id):
        with self._connect() as conn:
            conn.execute("UPDATE chat_messages SET deleted=1 WHERE id=?", (msg_id,))

    def get_chat_subscribers(self):
        with self._connect() as conn:
            return conn.execute("""
                SELECT user_id FROM users
                WHERE banned=0
                  AND role IN ('subscriber','contributor','admin','owner')
                  AND (role!='subscriber' OR access_end > datetime('now'))
            """).fetchall()

    # ══════════════════════════════════════════════════════════════════════════
    #  APORTES
    # ══════════════════════════════════════════════════════════════════════════
    def add_contribution(self, user_id, amount):
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO contributions (user_id, amount) VALUES (?, ?)", (user_id, amount)
            )

    def get_today_contribution(self, user_id):
        with self._connect() as conn:
            row = conn.execute("""
                SELECT COALESCE(SUM(amount),0) as total FROM contributions
                WHERE user_id=? AND date(contributed_at)=date('now')
            """, (user_id,)).fetchone()
            return row["total"] if row else 0

    def get_inactive_contributors(self):
        with self._connect() as conn:
            return conn.execute(f"""
                SELECT u.user_id FROM users u
                LEFT JOIN (
                    SELECT user_id, SUM(amount) as total FROM contributions
                    WHERE date(contributed_at)=date('now','-1 day') GROUP BY user_id
                ) c ON u.user_id=c.user_id
                WHERE u.role='contributor' AND u.banned=0
                  AND (c.total IS NULL OR c.total < {DAILY_MIN_CONTRIBUTION})
            """).fetchall()

    def get_contribution_stats(self, user_id):
        with self._connect() as conn:
            return conn.execute("""
                SELECT
                  SUM(CASE WHEN date(contributed_at)=date('now') THEN amount ELSE 0 END) as today,
                  SUM(amount) as total,
                  COUNT(*) as count
                FROM contributions WHERE user_id=?
            """, (user_id,)).fetchone()

    # ══════════════════════════════════════════════════════════════════════════
    #  CÓDIGOS DE REFERIDO
    # ══════════════════════════════════════════════════════════════════════════
    def create_referral_code(self, code, plan, created_by):
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO referral_codes (code, plan, created_by) VALUES (?, ?, ?)
            """, (code.upper(), plan, created_by))

    def get_referral_code(self, code):
        with self._connect() as conn:
            return conn.execute(
                "SELECT * FROM referral_codes WHERE code=? AND used_by IS NULL",
                (code.upper(),)
            ).fetchone()

    def use_referral_code(self, code, user_id):
        with self._connect() as conn:
            conn.execute("""
                UPDATE referral_codes SET used_by=?, used_at=datetime('now')
                WHERE code=?
            """, (user_id, code.upper()))

    def list_referral_codes(self, created_by):
        with self._connect() as conn:
            return conn.execute("""
                SELECT * FROM referral_codes WHERE created_by=? ORDER BY created_at DESC
            """, (created_by,)).fetchall()

    # ══════════════════════════════════════════════════════════════════════════
    #  AUDIT LOG
    # ══════════════════════════════════════════════════════════════════════════
    def log_action(self, actor_id, action, target_id=None, details=""):
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO audit_log (actor_id, action, target_id, details) VALUES (?,?,?,?)",
                (actor_id, action, target_id, details)
            )

    def get_audit_log(self, limit=50):
        with self._connect() as conn:
            return conn.execute(
                "SELECT * FROM audit_log ORDER BY done_at DESC LIMIT ?", (limit,)
            ).fetchall()
